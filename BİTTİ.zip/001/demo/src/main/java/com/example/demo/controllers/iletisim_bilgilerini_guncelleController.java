package com.example.demo.controllers;

public class iletisim_bilgilerini_guncelleController {
}
