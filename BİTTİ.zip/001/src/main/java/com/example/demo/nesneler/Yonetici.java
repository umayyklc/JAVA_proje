package com.example.demo.nesneler;

public class Yonetici extends Calisan {
    public Yonetici(int id, String isim, String soyisim, String eposta, String sifre, long telefon) {
        super(id, isim, soyisim, eposta, sifre, telefon);
    }
}
