package com.example.demo.controllers;

import com.example.demo.Personel;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import javax.management.StringValueExp;
import java.io.IOException;

public class personel_menuController {

    @FXML
    private Label idLabel;

    @FXML
    private Label departmanLabel;
    @FXML
    private Label pozisyonLabel;
    @FXML
    private Label maasLabel;
    @FXML
    private Label izinGunuLabel;
    @FXML
    private Label epostaLabel;
    @FXML
    private Label telefonLabel;

    private Personel personel;

    Stage stage;
    Scene scene;
    Parent root;

    public void setPersonel(Personel personel){
        //Bilgilerin ekrana yazdırıldığı kısım
        this.personel=personel;
        idLabel.setText("ID: "+String.valueOf(personel.getId()));
        departmanLabel.setText("Departman: "+personel.getDepartman());
        pozisyonLabel.setText("Pozisyon: "+personel.getPozisyon());
        maasLabel.setText("Maaş: "+String.valueOf(personel.getMaas()));
        izinGunuLabel.setText("İzin Günü: "+String.valueOf(personel.getIzin_gunu()));
        epostaLabel.setText("E-Posta: "+personel.getEposta());
        telefonLabel.setText("Telefon: "+String.valueOf(personel.getTelefon()));
    }

    public void cikis(ActionEvent event) throws IOException{
        FXMLLoader loader=new FXMLLoader(getClass().getResource("/com/example/demo/init.fxml"));
        root=loader.load();
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();
    }







}
