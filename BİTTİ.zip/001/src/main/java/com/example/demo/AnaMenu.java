package com.example.demo;

import javafx.event.ActionEvent;

import java.io.IOException;

public interface AnaMenu {
    void anaMenu(ActionEvent event) throws IOException;
}
