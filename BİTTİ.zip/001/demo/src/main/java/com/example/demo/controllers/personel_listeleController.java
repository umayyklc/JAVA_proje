package com.example.demo.controllers;

import com.example.demo.Personel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class personel_listeleController {

    @FXML
    private TableView<Personel> personelTable;

    @FXML
    private TableColumn<Personel, Integer> idColumn;

    @FXML
    private TableColumn<Personel, String> isimColumn;

    @FXML
    private TableColumn<Personel, String> soyisimColumn;

    @FXML
    private TableColumn<Personel, String> departmanColumn;

    @FXML
    private TableColumn<Personel, String> pozisyonColumn;

    @FXML
    private TableColumn<Personel, Double> maasColumn;

    @FXML
    private TableColumn<Personel, Integer> izinGunuColumn;

    @FXML
    private TableColumn<Personel, String> epostaColumn;

    @FXML
    private TableColumn<Personel, Long> telefonColumn;

    @FXML
    public void initialize() {
        // Kolonları getter metodlarına bağlama
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        isimColumn.setCellValueFactory(new PropertyValueFactory<>("isim"));
        soyisimColumn.setCellValueFactory(new PropertyValueFactory<>("soyisim"));
        departmanColumn.setCellValueFactory(new PropertyValueFactory<>("departman"));
        pozisyonColumn.setCellValueFactory(new PropertyValueFactory<>("pozisyon"));
        maasColumn.setCellValueFactory(new PropertyValueFactory<>("maas"));
        izinGunuColumn.setCellValueFactory(new PropertyValueFactory<>("izin_gunu"));
        epostaColumn.setCellValueFactory(new PropertyValueFactory<>("eposta"));
        telefonColumn.setCellValueFactory(new PropertyValueFactory<>("telefon"));

        // Örnek veri ekleme
        ObservableList<Personel> personeller = FXCollections.observableArrayList(
                new Personel(1, "Ali", "Veli", "ali@example.com", "1234", 5551234567L, "IT", "Yazılımcı", 15000, 10),
                new Personel(2, "Ayşe", "Yılmaz", "ayse@example.com", "5678", 5559876543L, "Muhasebe", "Muhasebeci", 12000, 8)
        );

        // Tabloya verileri ekleme
        personelTable.setItems(personeller);
    }
}
