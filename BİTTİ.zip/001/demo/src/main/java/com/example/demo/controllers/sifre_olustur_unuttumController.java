package com.example.demo.controllers;

import com.example.demo.Personel;
import com.example.demo.veri.SifreOlustur;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Optional;

public class sifre_olustur_unuttumController {

    Stage stage;
    Scene scene;
    Parent root;

    @FXML
    TextField epostaField;
    @FXML
    TextField parolaField;
    @FXML
    TextField paroladogrulaField;

    public void anaMenu() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/demo/init.fxml"));
        root=loader.load();
        stage=(Stage)epostaField.getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void onayla() throws IOException{
        String eposta=epostaField.getText();
        String sifre=parolaField.getText();
        String sifredogrula=paroladogrulaField.getText();

        Gson gson=new Gson();
        boolean check=false;
        Personel currentPersonel=null;
        try(FileReader reader=new FileReader("personel.json")){
            Type userListType=new TypeToken<List<Personel>>() {}.getType();
            List<Personel> personelListesi=gson.fromJson(reader, userListType);

            for(Personel personel: personelListesi){
                if(eposta.equals(personel.getEposta())){
                    check=true;
                    currentPersonel=personel;
                    break;
                }
            }
        }
        if(check){
            if(sifre.equals(sifredogrula)){
                Alert alert=new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Şifre Değiştir");
                alert.setTitle(null);
                alert.setContentText("Şifreyi değiştirmek istediğinize emin misiniz?");
                ButtonType yesButton=new ButtonType("Evet");
                ButtonType noButton=new ButtonType("Hayır");
                alert.getButtonTypes().setAll(yesButton, noButton);

                Optional<ButtonType> result=alert.showAndWait();
                if(result.isPresent() && result.get()==yesButton){
                    SifreOlustur.sifre_olustur(currentPersonel, sifre);
                    anaMenu();
                }



            }
            else{
                Alert alert=new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Hata");
                alert.setHeaderText(null);
                alert.setContentText("Sifreleri aynı giriniz!");
                alert.showAndWait();
            }
        }
        else{
            Alert alert=new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Hata");
            alert.setHeaderText(null);
            alert.setContentText("Bu epostaya sahip bir kullanıcı yok!");
            alert.showAndWait();
        }

    }
}
